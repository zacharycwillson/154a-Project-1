# Project 1 README

Student: Zachary Willson (922725803)

## Project Status
Circuits 1,2 & 3 are completed and working as expected.

## Known Issues
There are no known issues at this moment, as circuit 1, 2, & 3 are working as expected.

## References

## Generative AI Use
I used ChatGPT for Prompt 1 and 2.

### Prompt 1
list the numbers 0-31 in binary
### Response 1
Here are the numbers from 0 to 31 in binary:

Copy code
0  = 00000
1  = 00001
2  = 00010
3  = 00011
4  = 00100
5  = 00101
6  = 00110
7  = 00111
8  = 01000
9  = 01001
10 = 01010
11 = 01011
12 = 01100
13 = 01101
14 = 01110
15 = 01111
16 = 10000
17 = 10001
18 = 10010
19 = 10011
20 = 10100
21 = 10101
22 = 10110
23 = 10111
24 = 11000
25 = 11001
26 = 11010
27 = 11011
28 = 11100
29 = 11101
30 = 11110
31 = 11111
### Changes 1
Values were ordered into Circuit 3 turth table.
### Prompt 2
When making a 5 input kmap in a single grid, what is the ordering of the axis that has three terms?

### Response 2
When creating a 5-input Karnaugh map (K-map) in a single grid, one axis will represent three variables, and the other axis will represent the remaining two variables.

For the axis with three variables (let's say the variables are A, B, and C), the typical ordering is done in Gray code order to ensure that only one variable changes at a time as you move from one cell to the next. The Gray code sequence for three variables would be:

000
001
011
010
110
111
101
100
So, if you assign A, B, and C to the three-variable axis, the ordering would be:

Copy code
ABC
000
001
011
010
110
111
101
100
This ensures that adjacent cells in the K-map differ by only one bit, which is a key feature that allows you to easily identify groups of 1's that can be combined in the K-map.

If you need the other axis (with the two remaining variables, say D and E), the typical ordering is:

Copy code
DE
00
01
11
10
This 5-variable K-map will have a total of 32 cells, arranged in an 8x4 grid, where the 8 rows correspond to the possible combinations of the three-variable axis (ABC), and the 4 columns correspond to the combinations of the two-variable axis (DE).

### Changes 2
K-Map approach was abandoned for circuit 3 and thus the provdided information was not applied.
